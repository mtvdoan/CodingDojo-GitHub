var first= 9;
function add1(){
    var countElement = document.querySelector('#first') 
    first++;
    countElement.innerText = first + " likes(s)";
    console.log(first);  
}

var second= 12;
function add2(){
    var countElement = document.querySelector('#second')
    second++;
    countElement.innerText = second + " likes(s)";
    console.log(second);
}

var third= 9;
function add3(){
    var countElement = document.querySelector('#third')
    third++;
    countElement.innerText = third + " likes(s)";
    console.log(third);
}
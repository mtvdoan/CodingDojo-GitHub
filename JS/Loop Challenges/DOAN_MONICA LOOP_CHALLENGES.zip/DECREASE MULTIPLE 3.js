function one_point_five(num1,num2){
    let array = [];
    for(let i = num1; i >= num2; i-=1.5){
        array.push(i);
    }
    console.log(array);
}
one_point_five(4,-3.5);